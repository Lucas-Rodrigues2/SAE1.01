#ifndef MINIGAMES_H
#define MINIGAMES_H

#include "Tools.h"

/*
* Summary:
*   This function starts a Tic Tac Toe game between the two groups passed in parameter.
*   It manages the points of the winners and the logs of the game in the output file.
* 
* Parameters ([type] [optionals] varName):
*   [Group] [reference] group1: One of the two groups to the game.
*   [Group] [reference] group2: The other groups.
*   [vector<string>] [constant and reference] inputs: All inputs from both groups for the specific game.
*   [ofstream] [reference] logFile: The out file to mark the logs of the game.
*/
void ticTacToe(Group & group1, Group & group2, const std::vector<std::string> & inputs, std::ofstream & logFile);

/*
* Summary:
*   This function starts a Heads or Tails game between the two groups passed in parameter.
*   It manages the points of the winners and the logs of the game in the output file.
*   Compare to other gaming functions, there are no keyboard inputs.
*   The result of the coin toss is decided randomly (always the same with the seed initialized at the beginning). 
* 
* Parameters ([type] [optionals] varName):
*   [Group] [reference] group1: One of the two groups to the game.
*   [Group] [reference] group2: The other groups.
*   [ofstream] [reference] logFile: The out file to mark the logs of the game.
*/
void headsOrTails(Group & group1, Group & group2, std::ofstream & logFile);

/*
* Summary:
*   This function starts a Hangman game between the two groups passed in parameter.
*   It manages the points of the winners and the logs of the game in the output file. 
* 
* Parameters ([type] [optionals] varName):
*   [Group] [reference] group1: One of the two groups to the game.
*   [Group] [reference] group2: The other groups.
*   [vector<string>] [constant and reference] inputs: All inputs from both groups for the specific game.
*   [ofstream] [reference] logFile: The out file to mark the logs of the game.
*/
void hangman(Group & group1, Group & group2, const std::vector<std::string> & inputs, std::ofstream & logFile);

/*
* Summary:
*   This function starts a Hangman game between the two groups passed in parameter.
*   It manages the points of the winners and the logs of the game in the output file. 
* 
* Parameters ([type] [optionals] varName):
*   [Group] [reference] group1: One of the two groups to the game.
*   [Group] [reference] group2: The other groups.
*   [vector<string>] [constant and reference] inputs: All inputs from both groups for the specific game.
*   [ofstream] [reference] logFile: The out file to mark the logs of the game.
*/
void captainAge(Group & group1, Group & group2, const std::vector<std::string> & inputs, std::ofstream & logFile);

#endif