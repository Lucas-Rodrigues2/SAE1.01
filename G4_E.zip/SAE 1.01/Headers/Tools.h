#ifndef TOOLS_H
#define TOOLS_H

#include <iostream>
#include <vector>
#include <fstream>


// Structures
struct Person {
    std::string lastName;
    std::string FirstName;

    /*
    * Constructor of Person class
    *
    * Parameters ([type] [optionals] varName):
    *   [string] [constant and reference] _lastName: Last name of the player.
    *   [string] [constant and reference] _firstName: First name of the player.
    */
    Person(const std::string & _lastName, const std::string & _firstName);
};

struct Group {
    std::vector<Person> members;
    std::vector<Group> groupsFought;
    std::string name;
    float points;
    bool hasOpponent;

    /*
    * Constructor of Group class
    *
    * Parameters ([type] [optionals] varName):
    *   [string] [constant and reference] groupName: Name of the group.
    */
    Group(const std::string & groupName);

    /*
    * Summary:
    *   This method adds all the players in the group to the instance.
    * 
    * Parameters ([type] [optionals] varName):
    *   [vector<string>] [constant and reference] fileContent: Vector of string which contains all lines of the file in.
    *   [unsigned int] [constant and reference] lineStart: the number of line that start the first player name.
    */
    void buildGroup(const std::vector<std::string> & fileContent, const unsigned & lineStart);

    /*
    * Summary:
    *   This method check if this group instance has already confront the other group passed as parameter.
    * 
    * Parameters ([type] [optionals] varName):
    *   [Group] [constant and reference] currentGroup: The group that we want to check with this instance.
    * 
    * Return:
    *   bool: true -> if it's a old opponent.
    *         false -> if it's a new opponent.
    */
    bool isPreviousOpponent(const Group & currentGroup);

    /*
    * Summary:
    *   This method find a opponent at this instance.
    * 
    * Parameters ([type] [optionals] varName):
    *   [vector<Group>] [reference] allGroups: The list of all group of tournament.
    * 
    * Return:
    *   Group [reference]: the instance of the group opponent. 
    */
    Group & findOpponent(std::vector<Group> & allGroups);
};

// Functions
/*
* Summary:
*   This function displays in the out file an ASCII text.
*
* Parameters ([type] [optionals] varName):
*   [ofstream] [reference] logFile: The out file to mark the logs of the game.
*   [vector<string>] [constant and reference] text: The text to display as a string list for each line.
*   [vector<string>] [constant and reference] numberTurn: the round number to display as a string list for each line.
*/
void showAsciiText(std::ofstream & logFile, const std::vector<std::string> & text, const std::vector<std::string> & numberTurn);

/*
* Summary:
*   This function displays in the out file the tournament ranking.
*
* Parameters ([type] [optionals] varName):
*   [ofstream] [reference] logFile: The out file to mark the logs of the game.
*   [vector<string>] [reference] allGroups: The list of all group of tournament.
*   [vector<string>] [constant and reference] text: The ASCII "classification" text.
*/
void showRanking(std::ofstream & logFile, std::vector<Group> & allGroups, const std::vector<std::string> & text);

/*
* Summary:
*   This function is a predicate function used for sorting the vector which contains all groups.
*   Its a descending sort relative to points of groups.
*
* Parameters ([type] [optionals] varName):
*   [Group] [constant and reference] group1: first group to compare.
*   [Group] [constant and reference] group2: second group to compare.
*
* Return:
*   bool: true -> if group1 > group2
*         false -> if group1 < group2
*/
bool orderDescendingGroups(const Group & group1, const Group & group2);

/*
* Summary:
*   This function allows get a specific party to file content.
*   We used them to get just the inputs for a game between two groups.
*
* Parameters:
*   [vector<string>] [constant and reference] fileContent: The vector of string which contains all lines of the file in.
*   [unsigned int] [constante and reference] startIndexRead: The index where the first input to the game is found.
*
* Return:
*   vector<string>: The vector which contains a string for each input to the game. 
*/
std::vector<std::string> getInputsToGame(const std::vector<std::string> & fileContent, const unsigned & startIndexRead);

#endif