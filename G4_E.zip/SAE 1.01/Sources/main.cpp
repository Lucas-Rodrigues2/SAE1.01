// Include personal files
#include "../Headers/MiniGames.h"
#include "../Headers/TextASCII.h"


int main(int argc, char *argv[]) {
    if (argc != 3) {
        std::cout << "Le programme prend que deux parametres (le chemin du fichier d'entree et du fichier de sortie)"
                  << std::endl;
        return 1;
    }

    // Read the "settings file"
    std::ifstream fileIn;
    fileIn.open(argv[1]);
    
    std::vector<std::string> fileContent;
    std::string whollLine;
    std::string input;

    // build a vector of string which contains 1 string for each line except the line empty and comments "//"
    while (std::getline(fileIn, whollLine)) {
        
        for (unsigned i = 0; i < whollLine.size(); ++i) {
            if (whollLine[i] == '/' && whollLine[i + 1] == '/') break;
            input += whollLine[i];
        }

        if (input.size() == 0) continue;
        fileContent.push_back(input);
        input = "";
    }
    fileIn.close();

    // Set seed to random
    srand(stoul(fileContent[0], nullptr, 0));

    // Building groups and their members
    std::vector<Group> groups;
    for (unsigned i = 3; i < stoul(fileContent[1]) * 11; i += 11) {
        // "i = 3" = first group line ; "i += 11" = lines between two groups ; "fileContent[1]" = number of groups
        Group newGroup = Group(fileContent[i]);
        newGroup.buildGroup(fileContent, i + 1);
        groups.push_back(newGroup);
    }

    // Open to write in the out file
    std::ofstream logFile;
    logFile.open(argv[2]);

    unsigned startIndexInputs = 113; // first input after groups declaration

    // Start Tournament
    logFile << "Bienvenue à l'IUT Cup !" << std::endl
            << "10 groupes de 10 étudiants vont s'affronter durant 4 round sur divers mini-jeux." << std::endl
            << "L'équipe gagnante remporte 1 point et l'équipe perdante 0, en cas d'égalité chaque équipe gagnent 0.5 point."
            << std::endl << "Que le tournoi commence !" << std::endl;

    /* Round 1 (captain age)
    *  For the 1st round, all groups are 0 point so we don't need to sort them
    */
    showAsciiText(logFile, textRound, text1);

    for (unsigned i = 0; i < groups.size() / 2; ++i) {
        Group & group1 = groups[i];
        Group & group2 = groups[groups.size() - (i + 1)];

        // get in all file content, the inputs for the current game
        std::vector<std::string> currentInputs = getInputsToGame(fileContent, startIndexInputs);
        startIndexInputs += currentInputs.size() + 1; // next start input index

        group1.groupsFought.push_back(group2);
        group2.groupsFought.push_back(group1);

        captainAge(group1, group2, currentInputs, logFile);
    }
    showRanking(logFile, groups, textResult);
    

    // Round 2 (tic tac toe)
    showAsciiText(logFile, textRound, text2);

    for (unsigned i = 0; i < groups.size(); ++i) {
        if (groups[i].hasOpponent) continue;
        
        groups[i].hasOpponent = true;
        Group & opponent = groups[i].findOpponent(groups);
        opponent.hasOpponent = true;

        // get in all file content the inputs for the current game
        std::vector<std::string> currentInputs = getInputsToGame(fileContent, startIndexInputs);
        startIndexInputs += currentInputs.size() + 1; // next start input index

        groups[i].groupsFought.push_back(opponent);
        opponent.groupsFought.push_back(groups[i]);

        ticTacToe(groups[i], opponent, currentInputs, logFile);
    }

    // reset booleen variable for the next round to the matchmaking
    for (unsigned i = 0; i < groups.size(); ++i) {
        groups[i].hasOpponent = false;
    }
    showRanking(logFile, groups, textResult);


    // Round 3 (heads or tails)
    showAsciiText(logFile, textRound, text3);

    for (unsigned i = 0; i < groups.size(); ++i) {
        if (groups[i].hasOpponent) continue;
        
        groups[i].hasOpponent = true;
        Group & opponent = groups[i].findOpponent(groups);
        opponent.hasOpponent = true;

        groups[i].groupsFought.push_back(opponent);
        opponent.groupsFought.push_back(groups[i]);

        headsOrTails(groups[i], opponent, logFile);
    }

    // reset booleen variable for the next round to the matchmaking
    for (unsigned i = 0; i < groups.size(); ++i) {
        groups[i].hasOpponent = false;
    }
    showRanking(logFile, groups, textResult);

    // Round 4 (hangman)
    showAsciiText(logFile, textRound, text4);

    for (unsigned i = 0; i < groups.size(); ++i) {
        if (groups[i].hasOpponent) continue;
        
        groups[i].hasOpponent = true;
        Group & opponent = groups[i].findOpponent(groups);
        opponent.hasOpponent = true;

        // get in all file content the inputs for the current game
        std::vector<std::string> currentInputs = getInputsToGame(fileContent, startIndexInputs);
        startIndexInputs += currentInputs.size() + 1; // next start input index

        groups[i].groupsFought.push_back(opponent);
        opponent.groupsFought.push_back(groups[i]);

        hangman(groups[i], opponent, currentInputs, logFile);
    }

    // reset booleen variable for the next round to the matchmaking
    for (unsigned i = 0; i < groups.size(); ++i) {
        groups[i].hasOpponent = false;
    }
    showRanking(logFile, groups, textResult);


    // Result Tournament
    Group winnerGroup = groups[0]; // vector of groups already sorted by function showRanking
    logFile << std::endl << "Bien joué à l'équipe " << winnerGroup.name << " qui a remporté le tournoi avec "
            << winnerGroup.points << " points !" << std::endl;

    logFile.close();
    return 0;
}