// Include personal files
#include "../Headers/MiniGames.h"


void captainAge(Group & group1, Group & group2, const std::vector<std::string> & inputs, std::ofstream & logFile) {
    // Variables Initialize
    unsigned short tries = 8;
    unsigned short cptInput = 1;

    // Starting Game
    logFile << std::endl << "Le groupe '" << group1.name << "' va affronter le groupe '" << group2.name
            << "' au jeu de l'âge du capitaine." << std::endl
            << "Que le groupe '" << group1.name << "' saisisse l'âge du capitaine (entre 1 et 100) : " << inputs[0]
            << std::endl << std::endl;
    
    // Game loop
    while (tries > 0) {
        logFile << "Que le groupe '" << group2.name << "' saisissie un âge : " << inputs[cptInput] << std::endl;

        // Turn's result
        if (inputs[cptInput] > inputs[0]) {
            --tries;
            logFile << "Dommage, c'est moins !";

        } else if (inputs[cptInput] < inputs[0]) {
            --tries;
            logFile << "Dommage, c'est plus !";

        // case of group 2 win
        } else {
            logFile << "Bien joué ! Vous avez trouvé l'âge du capitaine." << std::endl << std::endl
                    << "Le groupe '" << group2.name << "' remporte 1 point." << std::endl;
            ++group2.points;
            return;
        }

        ++cptInput;
        logFile << " Il vous reste " << tries << " essais." << std::endl << std::endl;
    }
    
    // exit loop, case of group 1 win
    logFile << "Le groupe '" << group1.name << "remporte 1 point." << std::endl;
    ++group1.points;
}