// Include personal file
#include "../Headers/MiniGames.h"


/*
* Summary:
*   This function print on the out file the secret word at good format according to the letters already found.
*   Example for "famille" word with 'f' and 'l' letters found : f***ll*.
*
* Parameters:
*   [ofstream] [reference] logFile: The out file to mark the logs of the game.
*   [string] [constant and reference] secretWord: The word to find chosen by the first group.
*   [vector<unsigned int>] [constant and reference] posCharFind: The vector which contains all position of character already found.
*/
void displaySecretWord(std::ofstream & logFile, const std::string & secretWord, const std::vector<unsigned> & posCharFind) {
    bool isFind;
    
    for (unsigned i = 0; i < secretWord.size(); ++i) {
        isFind = false;

        for (unsigned j = 0; j < posCharFind.size(); ++j) {
            if (i == posCharFind[j]) {
                isFind = true;
                logFile << secretWord[i];
            }
        }

        if (!isFind)
            logFile << '*';
    }
}

void hangman(Group & group1, Group & group2, const std::vector<std::string> & inputs, std::ofstream & logFile) {
    // Variables initialize
    std::string secretWord;
    std::vector<char> charUsed;
    std::vector<unsigned> posCharFind;
    unsigned short cptInput = 1;
    unsigned short nbLife = 8;
    char currentCharInput;
    
    // Starting game
    logFile << std::endl
            << "Le groupe '" << group1.name << "' va affronter le groupe '" << group2.name << "' au jeu du pendu."
            << std::endl
            << "Le groupe '" << group1.name << "' va choisir un mot et le groupe '" << group2.name << "' va devoir le trouver."
            << std::endl
            << "Saisir le mot a trouver : ";
    
    // get and display the secret word
    secretWord = inputs[0];
    logFile << secretWord << std::endl << std::endl;


    while (nbLife > 0 && posCharFind.size() < secretWord.size()) {
        logFile << "Saisir une lettre : ";
        
        // get current char input
        currentCharInput = inputs[cptInput][0];
        charUsed.push_back(currentCharInput);

        // Check the occurences in the secret word
        bool isValidLetter = false;
        for (unsigned i = 0; i < secretWord.size(); ++i) {
            if (currentCharInput == tolower(secretWord[i])) {
                posCharFind.push_back(i);
                isValidLetter = true;
            }
        }

        // Print trace of result
        if (isValidLetter) {
            logFile << "Bien joué ! La lettre '" << currentCharInput << "' est bien dans le mot." << std::endl;

        } else {
            --nbLife;
            logFile << "Dommage ! La lettre '" << currentCharInput << "' n'est pas dans le mot." << std::endl
                    << "Il ne vous reste plus que " << nbLife << " point(s) de vie(s)." << std::endl;
        }

        ++cptInput;
        displaySecretWord(logFile, secretWord, posCharFind);
        logFile << std::endl << std::endl;
    }

    // Game Result
    logFile << "Bravo au groupe '";
    
    if (nbLife > 0) {
        group2.points += 1;
        logFile << group2.name;
    } else {
        group1.points += 1;
        logFile << group1.name;
    }

    logFile << "' qui gagne la partie ! Il remporte 1 point" << std::endl;
}